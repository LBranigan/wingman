const express = require('express');
const { PrismaClient } = require('@prisma/client');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Request matching
router.post('/request', authMiddleware, async (req, res) => {
  try {
    const currentUser = await prisma.user.findUnique({
      where: { id: req.userId }
    });
    
    if (currentUser.partnerId) {
      return res.status(400).json({ error: 'Already matched with a partner' });
    }
    
    // Find an unmatched user (excluding current user)
    const unmatchedUser = await prisma.user.findFirst({
      where: {
        AND: [
          { id: { not: req.userId } },
          { partnerId: null }
        ]
      }
    });
    
    if (!unmatchedUser) {
      return res.status(404).json({ error: 'No available partners at the moment' });
    }
    
    // Create mutual partnership
    await prisma.user.update({
      where: { id: req.userId },
      data: {
        partnerId: unmatchedUser.id,
        matchedAt: new Date()
      }
    });
    
    await prisma.user.update({
      where: { id: unmatchedUser.id },
      data: {
        partnerId: req.userId,
        matchedAt: new Date()
      }
    });
    
    res.json({
      message: 'Successfully matched!',
      partner: {
        id: unmatchedUser.id,
        name: unmatchedUser.name,
        bio: unmatchedUser.bio
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Unmatch
router.post('/unmatch', authMiddleware, async (req, res) => {
  try {
    const currentUser = await prisma.user.findUnique({
      where: { id: req.userId }
    });
    
    if (!currentUser.partnerId) {
      return res.status(400).json({ error: 'No partner to unmatch' });
    }
    
    // Remove partnership
    await prisma.user.update({
      where: { id: req.userId },
      data: { partnerId: null, matchedAt: null }
    });
    
    await prisma.user.update({
      where: { id: currentUser.partnerId },
      data: { partnerId: null, matchedAt: null }
    });
    
    res.json({ message: 'Successfully unmatched' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;