const express = require('express');
const { PrismaClient } = require('@prisma/client');
const authMiddleware = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

// Get current week's goals
router.get('/current-week', authMiddleware, async (req, res) => {
  try {
    const now = new Date();
    const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
    weekStart.setHours(0, 0, 0, 0);
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);
    
    const goals = await prisma.goal.findMany({
      where: {
        userId: req.userId,
        weekStart: {
          gte: weekStart,
          lt: weekEnd
        }
      },
      include: {
        comments: {
          include: {
            author: {
              select: {
                id: true,
                name: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'asc' }
    });
    
    res.json(goals);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get partner's current week goals
router.get('/partner/current-week', authMiddleware, async (req, res) => {
  try {
    const currentUser = await prisma.user.findUnique({
      where: { id: req.userId }
    });
    
    if (!currentUser.partnerId) {
      return res.status(400).json({ error: 'No partner assigned' });
    }
    
    const now = new Date();
    const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
    weekStart.setHours(0, 0, 0, 0);
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);
    
    const goals = await prisma.goal.findMany({
      where: {
        userId: currentUser.partnerId,
        weekStart: {
          gte: weekStart,
          lt: weekEnd
        }
      },
      include: {
        comments: {
          include: {
            author: {
              select: {
                id: true,
                name: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'asc' }
    });
    
    res.json(goals);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create a goal
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { text } = req.body;
    
    const now = new Date();
    const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
    weekStart.setHours(0, 0, 0, 0);
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);
    
    const goal = await prisma.goal.create({
      data: {
        text,
        userId: req.userId,
        weekStart,
        weekEnd
      }
    });
    
    res.status(201).json(goal);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle goal completion
router.patch('/:goalId/toggle', authMiddleware, async (req, res) => {
  try {
    const { goalId } = req.params;
    
    const goal = await prisma.goal.findUnique({
      where: { id: goalId }
    });
    
    if (!goal) {
      return res.status(404).json({ error: 'Goal not found' });
    }
    
    if (goal.userId !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    const updatedGoal = await prisma.goal.update({
      where: { id: goalId },
      data: { completed: !goal.completed }
    });
    
    res.json(updatedGoal);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete a goal
router.delete('/:goalId', authMiddleware, async (req, res) => {
  try {
    const { goalId } = req.params;
    
    const goal = await prisma.goal.findUnique({
      where: { id: goalId }
    });
    
    if (!goal) {
      return res.status(404).json({ error: 'Goal not found' });
    }
    
    if (goal.userId !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    await prisma.goal.delete({
      where: { id: goalId }
    });
    
    res.json({ message: 'Goal deleted' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;