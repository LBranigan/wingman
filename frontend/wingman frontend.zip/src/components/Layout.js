import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Target, Users, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Layout = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🤝</span>
              <h1 className="text-2xl font-bold text-gray-800">Wingman</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-medium text-gray-700">{user?.name}</span>
              <button
                onClick={logout}
                className="text-gray-600 hover:text-gray-800"
              >
                <LogOut size={20} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex gap-1">
            <Link
              to="/"
              className={`px-6 py-3 font-medium transition ${
                location.pathname === '/'
                  ? 'text-indigo-600 border-b-2 border-indigo-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Target className="inline mr-2" size={18} />
              My Goals
            </Link>
            <Link
              to="/partner"
              className={`px-6 py-3 font-medium transition ${
                location.pathname === '/partner'
                  ? 'text-indigo-600 border-b-2 border-indigo-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Users className="inline mr-2" size={18} />
              Partner
            </Link>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
};

export default Layout;