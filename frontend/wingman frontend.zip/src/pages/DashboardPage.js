import React, { useState, useEffect } from 'react';
import { Plus, CheckCircle2, Trash2, Target, AlertCircle } from 'lucide-react';
import { goals as goalsApi, match } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const DashboardPage = () => {
  const { user, refreshUser } = useAuth();
  const [goals, setGoals] = useState([]);
  const [newGoalText, setNewGoalText] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [matching, setMatching] = useState(false);

  useEffect(() => {
    loadGoals();
  }, []);

  const loadGoals = async () => {
    try {
      const response = await goalsApi.getCurrentWeek();
      setGoals(response.data);
    } catch (err) {
      setError('Failed to load goals');
    } finally {
      setLoading(false);
    }
  };

  const handleAddGoal = async () => {
    if (!newGoalText.trim()) return;

    try {
      const response = await goalsApi.create(newGoalText);
      setGoals([...goals, response.data]);
      setNewGoalText('');
    } catch (err) {
      setError('Failed to add goal');
    }
  };

  const handleToggleGoal = async (goalId) => {
    try {
      const response = await goalsApi.toggle(goalId);
      setGoals(goals.map(g => g.id === goalId ? response.data : g));
    } catch (err) {
      setError('Failed to update goal');
    }
  };

  const handleDeleteGoal = async (goalId) => {
    try {
      await goalsApi.delete(goalId);
      setGoals(goals.filter(g => g.id !== goalId));
    } catch (err) {
      setError('Failed to delete goal');
    }
  };

  const handleRequestMatch = async () => {
    setMatching(true);
    try {
      await match.request();
      await refreshUser();
      alert('Successfully matched with a partner!');
    } catch (err) {
      if (err.response?.status === 404) {
        alert('No available partners at the moment. Please try again later.');
      } else {
        alert('Failed to find a match');
      }
    } finally {
      setMatching(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  const completedGoals = goals.filter(g => g.completed).length;
  const progressPercentage = goals.length > 0 ? (completedGoals / goals.length) * 100 : 0;

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-2 text-red-700">
          <AlertCircle size={20} />
          {error}
        </div>
      )}

      {!user?.partner ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            No Partner Yet
          </h3>
          <p className="text-gray-600 mb-4">
            Get matched with an accountability partner to start your journey together!
          </p>
          <button
            onClick={handleRequestMatch}
            disabled={matching}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition disabled:opacity-50"
          >
            {matching ? 'Finding Partner...' : 'Find a Partner'}
          </button>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Your Accountability Partner</h3>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-2xl">
              👤
            </div>
            <div>
              <p className="font-semibold text-xl">{user.partner.name}</p>
              <p className="text-indigo-100 text-sm">{user.partner.bio}</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">My Weekly Goals</h2>
        
        <div className="flex gap-2 mb-6">
          <input
            type="text"
            value={newGoalText}
            onChange={(e) => setNewGoalText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddGoal()}
            placeholder="Add a new goal for this week..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
          <button
            onClick={handleAddGoal}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2"
          >
            <Plus size={20} />
            Add
          </button>
        </div>

        <div className="space-y-3">
          {goals.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Target size={48} className="mx-auto mb-3 opacity-50" />
              <p>No goals yet. Add your first goal above!</p>
            </div>
          ) : (
            goals.map((goal) => (
              <div
                key={goal.id}
                className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
              >
                <button
                  onClick={() => handleToggleGoal(goal.id)}
                  className={`flex-shrink-0 ${
                    goal.completed ? 'text-green-600' : 'text-gray-400'
                  }`}
                >
                  <CheckCircle2 size={24} />
                </button>
                <span
                  className={`flex-1 ${
                    goal.completed ? 'line-through text-gray-500' : 'text-gray-800'
                  }`}
                >
                  {goal.text}
                </span>
                <button
                  onClick={() => handleDeleteGoal(goal.id)}
                  className="text-red-500 hover:text-red-700 transition"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))
          )}
        </div>

        {goals.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-600">
                Progress: {completedGoals} of {goals.length} completed
              </span>
              <span className="font-semibold text-indigo-600">
                {Math.round(progressPercentage)}%
              </span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-600 transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;