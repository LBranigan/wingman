import React, { useState, useEffect } from 'react';
import { CheckCircle2, Send, AlertCircle } from 'lucide-react';
import { goals as goalsApi, comments as commentsApi } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const PartnerPage = () => {
  const { user } = useAuth();
  const [goals, setGoals] = useState([]);
  const [commentText, setCommentText] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user?.partner) {
      loadPartnerGoals();
    } else {
      setLoading(false);
    }
  }, [user]);

  const loadPartnerGoals = async () => {
    try {
      const response = await goalsApi.getPartnerCurrentWeek();
      setGoals(response.data);
    } catch (err) {
      setError('Failed to load partner goals');
    } finally {
      setLoading(false);
    }
  };

  const handleAddComment = async (goalId) => {
    const text = commentText[goalId]?.trim();
    if (!text) return;

    try {
      const response = await commentsApi.create(goalId, text);
      
      setGoals(goals.map(g => {
        if (g.id === goalId) {
          return {
            ...g,
            comments: [...g.comments, response.data]
          };
        }
        return g;
      }));

      setCommentText({ ...commentText, [goalId]: '' });
    } catch (err) {
      setError('Failed to add comment');
    }
  };

  const handleCommentChange = (goalId, value) => {
    setCommentText({ ...commentText, [goalId]: value });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!user?.partner) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-12 text-center">
        <div className="text-6xl mb-4">👥</div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">No Partner Yet</h2>
        <p className="text-gray-600 mb-6">
          You need to be matched with a partner first. Go to "My Goals" to find a partner.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-2 text-red-700">
          <AlertCircle size={20} />
          {error}
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-3xl text-white">
            👤
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{user.partner.name}</h2>
            <p className="text-gray-600">{user.partner.bio}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">This Week's Goals</h3>
        
        {goals.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p>Your partner hasn't set any goals yet for this week.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {goals.map((goal) => (
              <div key={goal.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start gap-3 mb-3">
                  <CheckCircle2
                    size={24}
                    className={goal.completed ? 'text-green-600' : 'text-gray-400'}
                  />
                  <div className="flex-1">
                    <span
                      className={`text-lg ${
                        goal.completed ? 'text-gray-600' : 'text-gray-800 font-medium'
                      }`}
                    >
                      {goal.text}
                    </span>
                    {goal.completed && (
                      <span className="ml-2 text-sm text-green-600 font-medium">
                        ✓ Completed
                      </span>
                    )}
                  </div>
                </div>

                <div className="ml-9 space-y-2">
                  {goal.comments.map((comment) => (
                    <div
                      key={comment.id}
                      className={`rounded p-3 text-sm ${
                        comment.author.id === user.id
                          ? 'bg-indigo-50 border border-indigo-100'
                          : 'bg-gray-50 border border-gray-100'
                      }`}
                    >
                      <span className="font-semibold text-gray-900">
                        {comment.author.name}:{' '}
                      </span>
                      <span className="text-gray-700">{comment.text}</span>
                      <div className="text-xs text-gray-500 mt-1">
                        {new Date(comment.createdAt).toLocaleString()}
                      </div>
                    </div>
                  ))}

                  <div className="flex gap-2 mt-3">
                    <input
                      type="text"
                      value={commentText[goal.id] || ''}
                      onChange={(e) => handleCommentChange(goal.id, e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddComment(goal.id)}
                      placeholder="Add encouragement or feedback..."
                      className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                    <button
                      onClick={() => handleAddComment(goal.id)}
                      className="bg-indigo-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-indigo-700 transition flex items-center gap-1"
                    >
                      <Send size={16} />
                      Send
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-6">
        <h4 className="font-semibold text-indigo-900 mb-2">💡 Tips for Great Feedback</h4>
        <ul className="text-sm text-indigo-800 space-y-1">
          <li>• Be specific about what you appreciate</li>
          <li>• Share how their progress inspires you</li>
          <li>• Offer constructive suggestions when appropriate</li>
          <li>• Celebrate their completed goals!</li>
        </ul>
      </div>
    </div>
  );
};

export default PartnerPage;