import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data)
};

export const users = {
  getMe: () => api.get('/users/me'),
  updateMe: (data) => api.put('/users/me', data)
};

export const match = {
  request: () => api.post('/match/request'),
  unmatch: () => api.post('/match/unmatch')
};

export const goals = {
  getCurrentWeek: () => api.get('/goals/current-week'),
  getPartnerCurrentWeek: () => api.get('/goals/partner/current-week'),
  create: (text) => api.post('/goals', { text }),
  toggle: (goalId) => api.patch(`/goals/${goalId}/toggle`),
  delete: (goalId) => api.delete(`/goals/${goalId}`)
};

export const comments = {
  create: (goalId, text) => api.post('/comments', { goalId, text })
};

export default api;